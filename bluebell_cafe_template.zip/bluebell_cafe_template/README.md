# Bluebell Café — interactive date invitation template

This is a one-file HTML/CSS/JavaScript template. It works locally in a browser and can be published with GitHub Pages or another static host.

## Quick start
1. Open `index.html` in VS Code.
2. Near the bottom, find `const CONFIG = { ... }`.
3. Edit the text, emojis, three pun objects, button labels, and colors.
4. Save, then open `index.html` in a browser to test it.
5. Test on a phone-sized window before sharing.

## Changing pictures
In `CONFIG.images`, paste a direct image URL into `page`, `welcome`, `game`, or `final`. Leave it as an empty string (`""`) to use the emoji illustration instead. For best results, use images you made yourself or have permission to use. If you want to use local images, put them in an `images` folder and use a relative path like `images/cafe.jpg`; make sure the file is uploaded with the site.

## Publishing with GitHub Pages
1. Create a new repository on GitHub.
2. Upload `index.html` (and any local image files/folders).
3. In the repository, open **Settings → Pages**.
4. Select deployment from the `main` branch and the root (`/`) folder, then save.
5. Wait for the published link to appear on the Pages settings screen.

## Important notes
- The website does not send you her answer or collect her data. The buttons only reveal messages in her browser; she'll still need to reply to you herself.
- The little blueberry chase is intentionally brief and has no failure state.
- Keep the page low-pressure and make sure the final invitation is clear.
